<footer>
    <div class="contaniner-fluid">
        <div class="row mx-3">
            <div class="col-md-4 col-lg-3"></div>
            <div class="col-md-4 col-lg-3"></div>
            <div class="col-md-4 col-lg-3"></div>
            <div class="col-md-4 col-lg-3">
                <h3>Siguenos</h3>
                <br>
                <div class="redes">
                    <a href="http://facebook.com"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="http://twitter.com"><i class="fa-brands fa-twitter"></i></a>
                    <a href="http://tiktok.com"><i class="fa-brands fa-tiktok"></i></a>
                </div>
            </div>

            <div class="col-12 text-white text-center">
            © <?php echo date("Y");?><a href="http://watsontic.com"> WatsonTic</a> Todos los derechos reservados
            </div>
        </div>
    </div>
</footer>