<header>
        <nav class="navbar navbar-expand-md bg-body-dark fixed-top">
            <div class="container-fluid">
                <a class="navbar-brand  ms-3 p-2" href="home">
                    <img class="img-fluid logo_chico" src="views/assets/img/logo_white.png"
                        alt="logo" height="60" width="60">
                    <img class="img-fluid logo_grande " src="views/assets/img/logo_grande_white.png"
                        alt="logo"  width="180">
                    </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas"
                    data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
                    <i class="fa-solid fa-bars-staggered fs-2"></i>

                </button>
                <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasNavbar"
                    aria-labelledby="offcanvasNavbarLabel">
                    <div class="offcanvas-header">
                        <h5 class="offcanvas-title ps-3" id="offcanvasNavbarLabel"><img class="img-fluid" width="100"
                                src="views/assets/img/logo_white.png" alt="logo"></h5>
                        <button type="button" class="btn btn-link text-white" data-bs-dismiss="offcanvas" aria-label="Close"><i class="fa-sharp fa-regular fa-xmark fa-2x"></i></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul class="navbar-nav justify-content-center flex-grow-1 pe-3">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="home">Inicio</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Nosotros</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link " href="#" role="button" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    Servicios <i class="fa-regular fa-angle-down"></i>
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="#">Action</a></li>
                                    <li><a class="dropdown-item" href="#">Another action</a></li>
                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>
                                    <li><a class="dropdown-item" href="#">Something else here</a></li>
                                </ul>
                            </li>
                          
                            <li class="nav-item">
                                <a class="nav-link" href="#">Trayectos</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Terminales</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Contacto</a>
                            </li>
                        </ul>
                        <div class="pais mx-5">
                            <img class="img-fluid" src="views/assets/img/peru.svg" alt="Perú" width="50">
                        </div>
                        <div class="buttons_l me-3">
                            <button type="button" class="btn btn-primary login mx-3">Iniciar Sesión</button>
                            <button type="button" class="btn btn-white register ">Registrarse</button>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </header>

