<?php 
session_start();

/*=============================================
Capturar las rutas de la URL
=============================================*/

$routesArray = explode("/", $_SERVER['REQUEST_URI']);
$routesArray = array_filter($routesArray);

/*=============================================
Limpiar la Url de variables GET
=============================================*/
foreach ($routesArray as $key => $value) {

  $value = explode("?", $value)[0];
  $routesArray[$key] = $value;
  
  
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FamaTours</title>

  <base href="<?php echo TemplateController::path() ?>">

  <link rel="icon" href="views/assets/img/logo.png">

  <!-- Google Font: Source Sans Pro 
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">-->
  <!-- Font Awesome -->
  <link rel="stylesheet" href="views/assets/plugins/fontawesome/css/all.min.css">
  <link rel="stylesheet" href="views/assets/plugins/bootstrap/bootstrap.min.css">
<!-- 
  <link rel="stylesheet" href="views/assets/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <link rel="stylesheet" href="views/assets/plugins/select2/select2.min.css">
  <link rel="stylesheet" href="views/assets/plugins/material-preloader/material-preloader.css">
  <link rel="stylesheet" href="views/assets/plugins/notie/notie.css">
  <link rel="stylesheet" href="views/assets/plugins/linearicons/linearicons.css">
  <link rel="stylesheet" href="views/assets/plugins/tags-input/tags-input.css">
  <link rel="stylesheet" href="views/assets/plugins/summernote/summernote-bs4.min.css">
  <link rel="stylesheet" href="views/assets/plugins/dropzone/dropzone.css">
 -->

   <!-- Template CSS -->
  <link rel="stylesheet" href="views/assets/css/style.css">

  <script src="views/assets/plugins/jquery/jquery.min.js"></script>
  <script src="views/assets/plugins/bootstrap/bootstrap.bundle.min.js"></script>

     <!--
  <script src="views/assets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <script src="views/assets/plugins/adminlte/js/adminlte.min.js"></script>
  <script src="views/assets/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
  <script src="views/assets/plugins/select2/select2.full.min.js"></script>
  <script src="views/assets/plugins/material-preloader/material-preloader.js"></script>
  <script src="views/assets/plugins/notie/notie.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
  <script src="views/assets/plugins/tags-input/tags-input.js"></script>
  <script src="views/assets/plugins/summernote/summernote-bs4.min.js"></script>
  <script src="views/assets/plugins/dropzone/dropzone.js"></script> -->

  <script src="views/assets/js/header.js"></script>


  <?php if (!empty($routesArray[1]) && !isset($routesArray[2])): ?>

    <?php if ($routesArray[1] == "admins" || 
             $routesArray[1] == "users" ||
             $routesArray[1] == "stores" ||
             $routesArray[1] == "categories" ||
             $routesArray[1] == "subcategories" ||
             $routesArray[1] == "products" ||
             $routesArray[1] == "orders" ||
             $routesArray[1] == "sales" ||
             $routesArray[1] == "disputes" ||
             $routesArray[1] == "messages"): ?>
     
        <!-- DataTables  & Plugins -->
        <!--<link rel="stylesheet" href="views/assets/plugins/daterangepicker/daterangepicker.css">
        <link rel="stylesheet" href="views/assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
        <link rel="stylesheet" href="views/assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
        <link rel="stylesheet" href="views/assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">

        <script src="views/assets/plugins/moment/moment.min.js"></script>
        <script src="views/assets/plugins/daterangepicker/daterangepicker.js"></script>
        <script src="views/assets/plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="views/assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="views/assets/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
        <script src="views/assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
        <script src="views/assets/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
        <script src="views/assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
        <script src="views/assets/plugins/jszip/jszip.min.js"></script>
        <script src="views/assets/plugins/pdfmake/pdfmake.min.js"></script>
        <script src="views/assets/plugins/pdfmake/vfs_fonts.js"></script>
        <script src="views/assets/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
        <script src="views/assets/plugins/datatables-buttons/js/buttons.print.min.js"></script>
        <script src="views/assets/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>-->


      <?php endif ?>

  <?php endif ?>

 

  <!-- <script src="views/assets/custom/alerts/alerts.js"></script> -->

</head>

<body>

  <?php 

  if(isset($_SESSION["admin"])){

   include "views/pages/login/login.php"; 

   echo '</body></head>';

   return;

  }


  ?>


  <?php include "views/modules/header.php"; ?>



    <?php

    if(!empty($routesArray[2])){

      if($routesArray[2] == "home" || 
 
         $routesArray[2] == "logout"){

        include "views/pages/".$routesArray[2]."/".$routesArray[2].".php";

      }else{

         include "views/pages/404/404.php"; 

      }

    }else{

      include "views/pages/home/home.php"; 
 
    }

    ?>
   
  



  <?php include "views/modules/footer.php"; ?>




</body>
</html>