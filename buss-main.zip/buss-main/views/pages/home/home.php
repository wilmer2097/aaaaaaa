<section class="portada">
    <div class="container">
        <div class="card consulta_viaje p-3  position-relative">
            <div class="row align-items-start ms-2">
                <div class="col-lg-12 mb-3">
                    <div class="d-flex">
                        <div class="form-check me-3">
                            <input class="form-check-input" type="radio" name="ida" id="ida" value="ida" checked>
                            <label class="form-check-label" for="ida">
                                Solo ida
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="ida" id="ida_vuelta" value="ida_vuelta">
                            <label class="form-check-label" for="ida_vuelta">
                            Ida y vuelta
                            </label>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="d-flex">
                        <div class="mb-3 position-relative">
                            <label for="desde" class="form-label">Desde</label>
                            <input type="text" class="form-control" id="desde" placeholder="Ciudad">
                            <ul class="list_desde"></ul>
                        </div>
                        <div class="mb-3  cam">
                        <label for="desde" class="form-label text-white">.</label>

                        <button type="button" class="btn btn-light" id="cambioLugarViaje"><i class="fa-regular fa-arrow-right-arrow-left"></i></button>
                        </div>

                        <div class="mb-3 position-relative">
                            <label for="destino" class="form-label">A</label>
                            <input type="text" class="form-control" id="destino" disabled placeholder="Destino">
                            <ul class="list_destino"></ul>

                        </div>
                    </div>
                </div>
                <div class="col-lg-2">
                    <div class="mb-3">
                        <label for="desde" class="form-label">Fecha de salida</label>
                        <input type="date" class="form-control" id="desde" placeholder="Ciudad">
                    </div>
                
                </div>
                <div class="col-lg-2 retorno">
                    <div class="mb-3">
                        <label for="desde" class="form-label">Fecha de retorno</label>
                        <input type="date" class="form-control" id="desde" placeholder="Ciudad">
                    </div>
                
                </div>
                <div class="col-lg-1">
                    <div class="mb-3">
                        <label for="desde" class="form-label">Asientos</label>
                        <input type="number" class="form-control" id="desde" placeholder="0" min="1" value="1">
                    </div>
                
                </div>
                <div class="col-lg-2">
                    <div class="btn_buscar">
                    <button type="button" class="btn btn-light ">Buscar</button>
                    </div>
                
                </div>
            </div>
            </div>
            
        </div>
    </div>

</section>
<section class="destinos pt-5">
    <div class="container pt-5">
        <div class="row">
            <div class="col-lg-12 mb-4"><h1 class="mt-5 text-white">Destinos</h1></div>
            <div class="col-lg-4 mb-4">
                <div class="card">
                    <div class="card-body">
                    
                    <h3><b>Lima</b> -  Capital del Perú</h3>
                    <br>
                    <img src="https://blog.uber-cdn.com/cdn-cgi/image/width=2160,quality=80,onerror=redirect,format=auto/wp-content/uploads/2019/04/Visita-estos-lugares-hist%C3%B3ricos-de-Lima-y-ent%C3%A9rate-de-su-interesante-pasado.png" class="img-fluid rounded " alt="lima">
                    <br>
                    </div>
                    <div class="card-footer text-center">
                    <button type="button" class="btn btn-primary ">Saber más...</button>

                    </div>
                </div>
            </div>
            <div class="col-lg-4  mb-4">
            <div class="card">
                    <div class="card-body">
                    
                    <h3><b>Lima</b> -  Capital del Perú</h3>
                    <br>
                    <img src="https://blog.uber-cdn.com/cdn-cgi/image/width=2160,quality=80,onerror=redirect,format=auto/wp-content/uploads/2019/04/Visita-estos-lugares-hist%C3%B3ricos-de-Lima-y-ent%C3%A9rate-de-su-interesante-pasado.png" class="img-fluid rounded " alt="lima">
                    <br>
                    </div>
                    <div class="card-footer text-center">
                    <button type="button" class="btn btn-primary ">Saber más...</button>

                    </div>
                </div>
            </div>
            <div class="col-lg-4  mb-4">
                <div class="card">
                    <div class="card-body">
                    
                    <h3><b>Lima</b> -  Capital del Perú</h3>
                    <br>
                    <img src="https://blog.uber-cdn.com/cdn-cgi/image/width=2160,quality=80,onerror=redirect,format=auto/wp-content/uploads/2019/04/Visita-estos-lugares-hist%C3%B3ricos-de-Lima-y-ent%C3%A9rate-de-su-interesante-pasado.png" class="img-fluid rounded " alt="lima">
                    <br>
                    </div>
                    <div class="card-footer text-center">
                    <button type="button" class="btn btn-primary ">Saber más...</button>

                    </div>
                </div>
            </div>
            <div class="col-lg-4  mb-4">
                <div class="card">
                    <div class="card-body">
                    
                    <h3><b>Lima</b> -  Capital del Perú</h3>
                    <br>
                    <img src="https://blog.uber-cdn.com/cdn-cgi/image/width=2160,quality=80,onerror=redirect,format=auto/wp-content/uploads/2019/04/Visita-estos-lugares-hist%C3%B3ricos-de-Lima-y-ent%C3%A9rate-de-su-interesante-pasado.png" class="img-fluid rounded " alt="lima">
                    <br>
                    </div>
                    <div class="card-footer text-center">
                    <button type="button" class="btn btn-primary ">Saber más...</button>

                    </div>
                </div>
            </div>
            <div class="col-lg-4  mb-4">
                <div class="card">
                    <div class="card-body">
                    
                    <h3><b>Lima</b> -  Capital del Perú</h3>
                    <br>
                    <img src="https://blog.uber-cdn.com/cdn-cgi/image/width=2160,quality=80,onerror=redirect,format=auto/wp-content/uploads/2019/04/Visita-estos-lugares-hist%C3%B3ricos-de-Lima-y-ent%C3%A9rate-de-su-interesante-pasado.png" class="img-fluid rounded " alt="lima">
                    <br>
                    </div>
                    <div class="card-footer text-center">
                    <button type="button" class="btn btn-primary ">Saber más...</button>

                    </div>
                </div>
            </div>
            <div class="col-lg-4  mb-4">
                <div class="card">
                    <div class="card-body">
                    
                    <h3><b>Lima</b> -  Capital del Perú</h3>
                    <br>
                    <img src="https://blog.uber-cdn.com/cdn-cgi/image/width=2160,quality=80,onerror=redirect,format=auto/wp-content/uploads/2019/04/Visita-estos-lugares-hist%C3%B3ricos-de-Lima-y-ent%C3%A9rate-de-su-interesante-pasado.png" class="img-fluid rounded " alt="lima">
                    <br>
                    </div>
                    <div class="card-footer text-center">
                    <button type="button" class="btn btn-primary ">Saber más...</button>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="medioPago my-4">
    <div class="container">
        <div class="card">
            <div class="card-header text-center py-3 bg-danger text-white">
                <h1><i class="fa-sharp fa-solid fa-credit-card"></i> <b>FACILIDADES DE PAGO</b></h1>
            </div>
            <div class="card-body py-5 text-center">
                <div class="row">
                    <div class="col-lg-3">BCP</div>
                    <div class="col-lg-3">Interbank</div>
                    <div class="col-lg-3">Yape</div>
                    <div class="col-lg-3">Plin</div>
                </div>

            </div>
        </div>
    </div>
</section>