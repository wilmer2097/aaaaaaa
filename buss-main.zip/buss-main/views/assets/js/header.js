$(document).ready(function() {


  $("input[name=ida]:radio").click(function() {
      if($(this).attr("value")=="ida") {
          $(".retorno").hide();
      }
      if($(this).attr("value")=="ida_vuelta") {
          $(".retorno").show();
      }
  });

  $('body').click(function() {

    if ($(".list_desde").css("display") == "block") {
      $('.list_desde').fadeOut();
         
       }
       if ($(".list_destino").css("display") == "block") {
        $('.list_destino').fadeOut();
           
         }
    
   });

    $( "#desde" ).change(function( event ) {

        event.preventDefault()

        $( "#destino" ).removeAttr("disabled")
        console.log("valu", $('#desde').val());
      });

   
      $( "#desde" ).click(function(event) {
        event.stopPropagation();
        
        $(".list_desde").css("display","block")
            let data = new FormData();
            data.append("ruta", true);
          
            let destin = [];
            $.ajax({
              url: "ajax/rutas.ajax.php",
              method: "POST",
              data: data,
              contentType: false,
              cache: false,
              processData: false,
              dataType: "json",
              success: function(response) {


                response.forEach(myFunction);
                function myFunction(item, index) {
                  let d = '<li val="'+item.origen+'">'+item.origen+'</li>';

                  if(!destin.includes(d)){
  
                    destin.push(d)
                  }

                }

                $(".list_desde").html(destin)

              }
  
            })
    });


    $('.list_desde').on("click","li", function() {

      let ori = $(this).attr("val");

      $( "#desde" ).val(ori)

      $( "#destino" ).removeAttr("disabled")
      
     });


     
     $( "#destino" ).click(function(event) {
      event.stopPropagation();
      
      $(".list_destino").show()

          let data = new FormData();
          data.append("destino", true);
          data.append("origen",  $("#desde").val());
        
          let destin = [];
          $.ajax({
            url: "ajax/rutas.ajax.php",
            method: "POST",
            data: data,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            success: function(response) {


              response.forEach(myFunction);
              function myFunction(item, index) {
                let d = '<li val="'+item.destino+'">'+item.destino+'</li>';

                if(!destin.includes(d)){

                  destin.push(d)
                }

              }

              $(".list_destino").html(destin)

            }

          })
  });


  $('.list_destino').on("click","li", function() {

    let ori = $(this).attr("val");

    $( "#destino" ).val(ori)
    
   });


   $("#cambioLugarViaje").click(function () {
    
    if ($("#desde").val() != "" && $("#destino").val() != "" )  {

      let or = $("#desde").val();
 console.log("or ", or);
      let des = $("#destino").val()
 console.log("des ", des);

      $("#desde").val(des)
      $("#destino").val(or)
      
    } else {
      
    }
   })

   $( "#desde" ).keyup(function() {
    $(".list_desde").hide()

    let inputSearch = $("#desde").val();


      let data = new FormData();
          data.append("rutaBuscar", inputSearch);
        
          let destin = [];
          $.ajax({
            url: "ajax/rutas.ajax.php",
            method: "POST",
            data: data,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            success: function(response) {


              response.forEach(myFunction);
              function myFunction(item, index) {
                let d = '<li val="'+item.origen+'">'+item.origen+'</li>';

                if(!destin.includes(d)){

                  destin.push(d)
                }
              

              }

              $(".list_desde").html(destin)
              $(".list_desde").show()
            }

          })
  });













});
