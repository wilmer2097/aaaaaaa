<?php
    require "../controllers/curl.controller.php";


    if (isset($_POST["ruta"])) {
       

        $url = "rutas";
        $method = "GET";
        $fields = array();
        
        $resp = CurlController::request($url,$method,$fields);

        echo json_encode($resp->results);
    }

    if (isset($_POST["rutaBuscar"])) {
       

        $url = "rutas?select=*&linkTo=origen&search=".$_POST["rutaBuscar"];
        $method = "GET";
        $fields = array();
        
        $resp = CurlController::request($url,$method,$fields);

        echo json_encode($resp->results);
    }

    if (isset($_POST["origen"]) && isset($_POST["destino"])) {
       

        $url = "rutas?select=*&linkTo=origen&search=".$_POST["origen"];
        $method = "GET";
        $fields = array();
        
        $resp = CurlController::request($url,$method,$fields);

        echo json_encode($resp->results);
    }
?>